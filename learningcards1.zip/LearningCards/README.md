# LearningCards
## a GIT Test

Natali Filatov

This repository is hosted  at:
https://github.com/Natali99999/LearningCards.git


https://github.com/github/gitignore/blob/master/Global/Eclipse.gitignore
