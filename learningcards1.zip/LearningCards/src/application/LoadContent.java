package application;

//import java.io.IOException;

//import javafx.fxml.FXMLLoader;

public class LoadContent {
   public LoadContent(String fileName) {
	   /*FXMLLoader fxmlLLoader = new FXMLLoader(getClass().getResource(fxmlFileName));
		
		try {
			borderPane.setCenter(fxmlLLoader.load());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
   }
}
