package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import models.Constants;
import models.View;
import models.ViewSwitcher;
import javafx.scene.Scene;

import javafx.scene.image.Image;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.fxml.FXMLLoader;



public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("app.fxml"));
			Scene scene = new Scene(root, 900,500);
			
			//Scene scene = new Scene(new BorderPane());
		    ViewSwitcher.setScene(scene);
		    ViewSwitcher.setClass(getClass());
		    
		    ViewSwitcher.setBorderPane(root);
		  //  ViewSwitcher.switchTo(View.MAIN);

		    scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			// Icon �ndern
			Image icon = new Image(getClass().getResourceAsStream("/resources/java_icon.png"));
			primaryStage.getIcons().add(icon);
		
			 
			primaryStage.setTitle(Constants.APPTITLE);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
