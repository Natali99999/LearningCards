package models;

public class Constants {
	public static final String APPTITLE = "Learning cards";
	
	public static final String START_FILE = "start.fxml";
	public static final String LEARN_FILE = "learn.fxml";
	
	
}
