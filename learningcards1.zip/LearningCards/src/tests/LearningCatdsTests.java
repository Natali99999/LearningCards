package tests;

import org.junit.Test;

public class LearningCatdsTests {
	@Test
	public void test1(){
		
	}
}
